public interface Backtrack {
    void backtrack();
    void retrack();
}
